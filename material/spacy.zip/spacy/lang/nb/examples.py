# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.nb.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple vurderer å kjøpe britisk oppstartfirma for en milliard dollar.",
    "Selvkjørende biler flytter forsikringsansvaret over på produsentene.",
    "San Francisco vurderer å forby robotbud på fortauene.",
    "London er en stor by i Storbritannia.",
]
