# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.id.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Al Qaidah mengklaim bom mobil yang menewaskan 60 Orang di Mali",
    "Abu Sayyaf mengeksekusi sandera warga Filipina",
    "Penyaluran pupuk berasal dari lima lokasi yakni Bontang, Kalimantan Timur, Surabaya, Banyuwangi, Semarang, dan Makassar.",
    "PT Pupuk Kaltim telah menyalurkan 274.707 ton pupuk bersubsidi ke wilayah penyaluran di 14 provinsi.",
    "Jakarta adalah kota besar yang nyaris tidak pernah tidur."
    "Kamu ada di mana semalam?",
    "Siapa yang membeli makanan ringan tersebut?",
    "Siapa presiden pertama Republik Indonesia?",
]
